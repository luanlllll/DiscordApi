const fs = require('node:fs');
const path = require('node:path');
const { Client, Collection, Events, GatewayIntentBits, MessageFlags } = require('discord.js');
const { token } = require('./config.json');
const cron = require('node-cron');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers, 
        GatewayIntentBits.GuildMessages
    ]
});

client.commands = new Collection();

const foldersPath = path.join(__dirname, 'commands');
const commandFolders = fs.readdirSync(foldersPath);

for (const folder of commandFolders) {
    const commandsPath = path.join(foldersPath, folder);
    
    // Verificação de segurança para garantir que é uma pasta
    if (!fs.lstatSync(commandsPath).isDirectory()) continue;

    const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith('.js'));
    for (const file of commandFiles) {
        const filePath = path.join(commandsPath, file);
        const command = require(filePath);

        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
        } else {
            console.log(`[WARNING] The command at ${filePath} is missing "data" or "execute".`);
        }
    }
}

client.once(Events.ClientReady, (readyClient) => {
    console.log(`✅ Ready! Logged in as ${readyClient.user.tag}`);
});

// LOGIN
client.login(token);

client.on(Events.InteractionCreate, async (interaction) => {
    // --- LÓGICA DE AUTOCOMPLETE ---
    if (interaction.isAutocomplete()) {
        const command = interaction.client.commands.get(interaction.commandName);

        if (!command) return;

        try {
            await command.autocomplete(interaction);
        } catch (error) {
            console.error(error);
        }
        return; // Importante retornar aqui para não tentar executar como comando normal
    }

    // --- LÓGICA DE COMANDO NORMAL ---
    if (!interaction.isChatInputCommand()) return;

    const command = interaction.client.commands.get(interaction.commandName);

    if (!command) {
        console.error(`No command matching ${interaction.commandName} was found.`);
        return;
    }

    try {
        await command.execute(interaction);
    } catch (error) {
        console.error(error);
        const errorMsg = { content: 'There was an error while executing this command!', flags: MessageFlags.Ephemeral };
        
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp(errorMsg);
        } else {
            await interaction.reply(errorMsg);
        }
    }
});

// TAREFA AGENDADA: Roda todo dia 1 de cada mês às 00:00
cron.schedule('0 0 1 * *', async () => {
    console.log("⚔️ Sparta: Iniciando manutenção de armamento (Ferrugem)...");

    // Buscamos todos os dados do banco
    const allData = await db.all();

    for (const entry of allData) {
        // Procuramos por chaves que começam com inventario_
        if (entry.id.startsWith('inventario_')) {
            let inv = entry.value;
            let mudou = false;

            // Lista de itens que podem enferrujar
            const itensEnferrujaveis = ['espada_ferro', 'escudo_ferro', 'lança_ferro'];

            for (const item of itensEnferrujaveis) {
                if (inv[item] && inv[item] > 0) {
                    const qtd = inv[item];
                    const novoItem = `danificado_${item}`;

                    // muda o item
                    inv[novoItem] = (inv[novoItem] || 0) + qtd;
                    delete inv[item]; // Remove o original
                    mudou = true;
                }
            }

            if (mudou) {
                await db.set(entry.id, inv);
                console.log(`Log: Inventário de ${entry.id} sofreu corrosão.`);
            }
        }
    }
    console.log(" Manutenção concluída.");
});
